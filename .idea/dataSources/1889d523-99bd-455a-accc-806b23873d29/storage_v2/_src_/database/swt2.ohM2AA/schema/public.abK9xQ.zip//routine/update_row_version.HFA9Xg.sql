create function update_row_version()
  returns trigger
language plpgsql
as $$
BEGIN
  new.version = old.version + 1;
  return new;
END
$$;

alter function update_row_version()
  owner to swt2;

